%% lane_change_4ws.m
% Linear bicycle model of a four-wheel-steering (4WS) vehicle.
%
% Part 1: compares 2WS, opposite-phase 4WS and same-phase 4WS (fixed rear
%         gain K, delta_r = K * delta_f) over a double lane change at 50 km/h.
% Part 2: speed-scheduled rear gain K*(V) that zeroes steady-state sideslip,
%         and a highway-speed comparison showing why a fixed K is not enough.
%
% Figures are saved to ../results/.
clear; clc; close all;

outDir = fullfile(fileparts(mfilename('fullpath')), '..', 'results');
if ~exist(outDir, 'dir'); mkdir(outDir); end

%% Vehicle parameters
p.m  = 1270;      % mass (kg)
p.Iz = 1536.7;    % yaw inertia (kg m^2)
p.lf = 1.015;     % CG to front axle (m)
p.lr = 1.895;     % CG to rear axle (m)
p.Cf = 80000;     % front cornering stiffness (N/rad)
p.Cr = 80000;     % rear cornering stiffness (N/rad)

%% Part 1: fixed-gain comparison at 50 km/h
Vx = 13.89;   % 50 km/h
K_values   = [0, -0.3, 0.2];   % 2WS, opposite-phase 4WS, same-phase 4WS
case_names = {'2WS', '4WS Opposite Phase', '4WS Same Phase'};

results = cell(numel(K_values), 1);
for i = 1:numel(K_values)
    results{i} = simulate(p, Vx, K_values(i));
    results{i}.name = case_names{i};
end

plot_cases(results, @(r) rad2deg(r.delta_f), '\delta_f (deg)', 'Front Steering Input', fullfile(outDir, 'front_steering.png'));
plot_cases(results, @(r) rad2deg(r.delta_r), '\delta_r (deg)', 'Rear Steering Input',  fullfile(outDir, 'rear_steering.png'));
plot_cases(results, @(r) rad2deg(r.beta),    '\beta (deg)',     'Sideslip Angle Response', fullfile(outDir, 'sideslip.png'));
plot_cases(results, @(r) rad2deg(r.r),       'r (deg/s)',       'Yaw Rate Response',  fullfile(outDir, 'yaw_rate.png'));
plot_cases(results, @(r) r.y,                'Lateral position y (m)', 'Lane Change Lateral Motion', fullfile(outDir, 'lateral_position.png'));

fprintf('50 km/h peak values:\n');
for i = 1:numel(results)
    fprintf('  %-20s  |beta| = %.2f deg   |r| = %.1f deg/s   y_final = %.2f m\n', ...
        results{i}.name, max(abs(rad2deg(results{i}.beta))), ...
        max(abs(rad2deg(results{i}.r))), results{i}.y(end));
end

%% Part 2: speed-scheduled rear steering gain
% Setting d(beta)/dt = d(r)/dt = 0 and beta = 0 in the bicycle model gives
%   K*(V) = -(lr - m*lf*V^2/(Cr*L)) / (lf + m*lr*V^2/(Cf*L))
% Negative (opposite phase) at low speed, positive (same phase) at high speed.
L = p.lf + p.lr;
Kstar = @(V) -(p.lr - p.m*p.lf*V.^2/(p.Cr*L)) ./ (p.lf + p.m*p.lr*V.^2/(p.Cf*L));
V0 = sqrt(p.Cr*p.lr*L/(p.m*p.lf));   % speed where K* changes sign

V = linspace(1, 40, 400);
figure;
plot(V*3.6, Kstar(V), 'LineWidth', 1.6); hold on;
yline(0, 'k:');
xline(V0*3.6, '--', sprintf('%.0f km/h', V0*3.6));
xlabel('Speed (km/h)'); ylabel('K^* = \delta_r / \delta_f');
title('Zero-Sideslip Rear Steering Gain vs Speed');
grid on;
saveas(gcf, fullfile(outDir, 'k_schedule.png'));

fprintf('\nK* at 50 km/h = %.3f, sign change at %.1f km/h\n', Kstar(13.89), V0*3.6);

% Highway check: fixed opposite-phase gain vs scheduled gain at 100 km/h
Vh = 27.78;
hw = {simulate(p, Vh, 0), simulate(p, Vh, -0.3), simulate(p, Vh, Kstar(Vh))};
hw{1}.name = '2WS';
hw{2}.name = 'Fixed K = -0.3';
hw{3}.name = sprintf('Scheduled K^* = %.2f', Kstar(Vh));
plot_cases(hw, @(r) rad2deg(r.beta), '\beta (deg)', 'Sideslip at 100 km/h', fullfile(outDir, 'sideslip_100kmh.png'));
plot_cases(hw, @(r) rad2deg(r.r),    'r (deg/s)',   'Yaw Rate at 100 km/h', fullfile(outDir, 'yaw_rate_100kmh.png'));

%% ---------------------------------------------------------------------
function res = simulate(p, Vx, K)
    f = @(t, x) bicycle_4ws_dynamics(t, x, p, Vx, K);
    [t, x] = ode45(f, [0 6], zeros(4, 1));   % x = [beta; r; psi; y]

    delta_f = zeros(size(t));
    delta_r = zeros(size(t));
    for k = 1:numel(t)
        [delta_f(k), delta_r(k)] = steering_profile(t(k), K);
    end

    res = struct('t', t, 'beta', x(:,1), 'r', x(:,2), 'psi', x(:,3), 'y', x(:,4), ...
                 'delta_f', delta_f, 'delta_r', delta_r);
end

function dx = bicycle_4ws_dynamics(t, x, p, Vx, K)
    beta = x(1);
    r    = x(2);
    psi  = x(3);

    [delta_f, delta_r] = steering_profile(t, K);

    dbeta = (-(p.Cf + p.Cr)/(p.m*Vx))*beta ...
          + ((p.Cr*p.lr - p.Cf*p.lf)/(p.m*Vx^2) - 1)*r ...
          + (p.Cf/(p.m*Vx))*delta_f ...
          + (p.Cr/(p.m*Vx))*delta_r;

    dr = ((p.lr*p.Cr - p.lf*p.Cf)/p.Iz)*beta ...
       - ((p.lf^2*p.Cf + p.lr^2*p.Cr)/(p.Iz*Vx))*r ...
       + (p.lf*p.Cf/p.Iz)*delta_f ...
       - (p.lr*p.Cr/p.Iz)*delta_r;

    dpsi = r;
    dy   = Vx * (beta + psi);   % small-angle lateral kinematics

    dx = [dbeta; dr; dpsi; dy];
end

function [delta_f, delta_r] = steering_profile(t, K)
    % Double lane change: half-sine pulses left, right, left, right
    A = deg2rad(4.5);
    pulses = [0.5 1.1  1; 1.5 2.1 -1; 2.5 3.1  1; 3.5 4.1 -1];   % [start end sign]

    delta_f = 0;
    for k = 1:size(pulses, 1)
        if t >= pulses(k,1) && t < pulses(k,2)
            delta_f = pulses(k,3) * A * sin(pi*(t - pulses(k,1))/(pulses(k,2) - pulses(k,1)));
        end
    end
    delta_r = K * delta_f;
end

function plot_cases(results, getter, ylab, ttl, outFile)
    figure;
    for i = 1:numel(results)
        plot(results{i}.t, getter(results{i}), 'LineWidth', 1.4); hold on;
    end
    xlabel('Time (s)'); ylabel(ylab);
    legend(cellfun(@(r) r.name, results, 'UniformOutput', false), 'Location', 'best');
    title(ttl); grid on;
    saveas(gcf, outFile);
end
