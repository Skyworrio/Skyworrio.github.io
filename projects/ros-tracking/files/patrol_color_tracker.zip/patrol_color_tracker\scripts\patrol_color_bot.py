#!/usr/bin/env python
"""Patrol a square path with move_base and break off to follow a colored target.

State machine:
    PATROL -> drive a square of waypoints via move_base; switch to FOLLOW when
              the target color is seen.
    FOLLOW -> steer toward the target's image centroid with a proportional
              controller on cmd_vel; switch to RETURN when the target is lost.
    RETURN -> navigate back to the nearest patrol waypoint, then resume PATROL
              (or go straight back to FOLLOW if the target reappears).
"""
import math
import rospy
import actionlib
import tf
import cv2
import numpy as np

from cv_bridge import CvBridge
from geometry_msgs.msg import Twist, Quaternion
from sensor_msgs.msg import Image
from move_base_msgs.msg import MoveBaseAction, MoveBaseGoal
from actionlib_msgs.msg import GoalStatus


def quat(yaw):
    return Quaternion(0, 0, math.sin(yaw / 2.0), math.cos(yaw / 2.0))


class PatrolColorBot:
    def __init__(self):
        rospy.init_node("patrol_color_bot")

        self.image_topic = rospy.get_param("~image_topic", "/camera/rgb/image_raw")
        self.cmd_vel_topic = rospy.get_param("~cmd_vel_topic", "/cmd_vel")
        self.base_frame = rospy.get_param("~base_frame", "base_link")
        self.map_frame = rospy.get_param("~map_frame", "map")

        # Patrol square side length (m); default is 1 ft
        self.side = rospy.get_param("~side", 0.3048)

        # HSV threshold for the target color (default: red, low-hue band)
        self.hsv_low = np.array([
            rospy.get_param("~h", 0),
            rospy.get_param("~s", 120),
            rospy.get_param("~v", 70)
        ])
        self.hsv_high = np.array([
            rospy.get_param("~h2", 10),
            rospy.get_param("~s2", 255),
            rospy.get_param("~v2", 255)
        ])

        # Blobs smaller than this (px^2) are ignored to reject false detections
        self.min_area = rospy.get_param("~min_area", 1500)

        # Follow controller
        self.kp = rospy.get_param("~kp", 0.004)                 # rad/s per px of error
        self.max_ang = rospy.get_param("~max_angular", 0.8)     # rad/s
        self.lin_speed = rospy.get_param("~linear_speed", 0.12) # m/s
        self.lost_timeout = rospy.get_param("~lost_timeout", 0.7)  # s

        self.bridge = CvBridge()
        self.tf = tf.TransformListener()
        self.cmd_pub = rospy.Publisher(self.cmd_vel_topic, Twist, queue_size=1)
        rospy.Subscriber(self.image_topic, Image, self.image_cb, queue_size=1)

        self.mb = actionlib.SimpleActionClient("/move_base", MoveBaseAction)
        self.mb.wait_for_server()

        self.seen = False
        self.last_seen = rospy.Time(0)
        self.cx = None
        self.w = None

        self.state = "PATROL"
        self.goal_active = False
        self.wp = self.make_square()
        self.i = 0

    def pose(self):
        """Return (x, y, yaw) of the robot in the map frame, or None if TF is unavailable."""
        try:
            self.tf.waitForTransform(self.map_frame, self.base_frame, rospy.Time(0), rospy.Duration(1.0))
            (p, q) = self.tf.lookupTransform(self.map_frame, self.base_frame, rospy.Time(0))
            yaw = tf.transformations.euler_from_quaternion(q)[2]
            return p[0], p[1], yaw
        except (tf.Exception, tf.LookupException, tf.ConnectivityException, tf.ExtrapolationException):
            return None

    def make_square(self):
        """Build four waypoints forming a square, starting at the robot's current pose."""
        p = self.pose()
        while p is None and not rospy.is_shutdown():
            p = self.pose()
            rospy.sleep(0.1)

        x, y, yaw = p
        dx = math.cos(yaw) * self.side
        dy = math.sin(yaw) * self.side
        px = -math.sin(yaw) * self.side
        py = math.cos(yaw) * self.side

        return [
            (x, y, yaw),
            (x + dx, y + dy, yaw),
            (x + dx + px, y + dy + py, yaw),
            (x + px, y + py, yaw),
        ]

    def image_cb(self, msg):
        """Threshold the frame in HSV and record the centroid of the largest valid blob."""
        img = self.bridge.imgmsg_to_cv2(msg, "bgr8")
        self.w = img.shape[1]

        hsv = cv2.cvtColor(img, cv2.COLOR_BGR2HSV)
        mask = cv2.inRange(hsv, self.hsv_low, self.hsv_high)
        cnts = cv2.findContours(mask, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)
        cnts = cnts[0] if len(cnts) == 2 else cnts[1]  # OpenCV 3 vs 4 return signature

        if not cnts:
            self.seen = False
            return

        c = max(cnts, key=cv2.contourArea)
        if cv2.contourArea(c) < self.min_area:
            self.seen = False
            return

        m = cv2.moments(c)
        if m["m00"] == 0:
            self.seen = False
            return

        self.cx = int(m["m10"] / m["m00"])
        self.seen = True
        self.last_seen = rospy.Time.now()

    def stop(self):
        self.cmd_pub.publish(Twist())

    def send_goal(self, x, y, yaw):
        g = MoveBaseGoal()
        g.target_pose.header.frame_id = self.map_frame
        g.target_pose.header.stamp = rospy.Time.now()
        g.target_pose.pose.position.x = x
        g.target_pose.pose.position.y = y
        g.target_pose.pose.orientation = quat(yaw)
        self.mb.send_goal(g)
        self.goal_active = True

    def follow_color(self):
        """Steer toward the target centroid. Returns False once the target is lost."""
        if not self.seen or self.cx is None or self.w is None:
            self.stop()
            return False

        err = self.cx - (self.w // 2)
        t = Twist()
        t.angular.z = max(-self.max_ang, min(self.max_ang, -self.kp * err))
        t.linear.x = self.lin_speed
        self.cmd_pub.publish(t)

        if (rospy.Time.now() - self.last_seen).to_sec() > self.lost_timeout:
            return False
        return True

    def nearest_wp(self):
        p = self.pose()
        if p is None:
            return self.i
        x, y, _ = p
        best = 0
        dist = float("inf")
        for n, (wx, wy, _) in enumerate(self.wp):
            d = math.hypot(x - wx, y - wy)
            if d < dist:
                dist = d
                best = n
        return best

    def run(self):
        rate = rospy.Rate(10)

        while not rospy.is_shutdown():
            if self.state == "PATROL":
                if self.seen:
                    self.mb.cancel_all_goals()
                    self.stop()
                    self.state = "FOLLOW"
                else:
                    if not self.goal_active:
                        self.send_goal(*self.wp[self.i])
                    elif self.mb.get_state() == GoalStatus.SUCCEEDED:
                        self.goal_active = False
                        self.i = (self.i + 1) % len(self.wp)

            elif self.state == "FOLLOW":
                if not self.follow_color():
                    self.stop()
                    self.state = "RETURN"
                    self.goal_active = False
                    self.mb.cancel_all_goals()

            elif self.state == "RETURN":
                if self.seen:
                    self.state = "FOLLOW"
                else:
                    if not self.goal_active:
                        self.i = self.nearest_wp()
                        self.send_goal(*self.wp[self.i])
                    elif self.mb.get_state() == GoalStatus.SUCCEEDED:
                        self.goal_active = False
                        self.state = "PATROL"
                        self.i = (self.i + 1) % len(self.wp)

            rate.sleep()


if __name__ == "__main__":
    PatrolColorBot().run()
