"""Linear bicycle model of a four-wheel-steering (4WS) vehicle.

Python port of ../matlab/lane_change_4ws.m (no MATLAB license needed).

Part 1: 2WS vs opposite-phase vs same-phase 4WS (fixed rear gain K,
        delta_r = K * delta_f) over a double lane change at 50 km/h.
Part 2: speed-scheduled rear gain K*(V) that zeroes steady-state sideslip,
        plus a 100 km/h comparison against a fixed gain.

Figures are written to ../results/.
"""
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
from scipy.integrate import solve_ivp

OUT_DIR = Path(__file__).resolve().parent.parent / "results"

# Vehicle parameters
M = 1270.0      # mass (kg)
IZ = 1536.7     # yaw inertia (kg m^2)
LF = 1.015      # CG to front axle (m)
LR = 1.895      # CG to rear axle (m)
CF = 80000.0    # front cornering stiffness (N/rad)
CR = 80000.0    # rear cornering stiffness (N/rad)
L = LF + LR

# Double lane change: half-sine pulses [start, end, sign]
AMP = np.deg2rad(4.5)
PULSES = [(0.5, 1.1, 1), (1.5, 2.1, -1), (2.5, 3.1, 1), (3.5, 4.1, -1)]


def steering_profile(t, k):
    delta_f = 0.0
    for t0, t1, sgn in PULSES:
        if t0 <= t < t1:
            delta_f = sgn * AMP * np.sin(np.pi * (t - t0) / (t1 - t0))
    return delta_f, k * delta_f


def dynamics(t, x, vx, k):
    beta, r, psi, _ = x
    delta_f, delta_r = steering_profile(t, k)

    dbeta = (-(CF + CR) / (M * vx)) * beta \
        + ((CR * LR - CF * LF) / (M * vx**2) - 1) * r \
        + (CF / (M * vx)) * delta_f \
        + (CR / (M * vx)) * delta_r

    dr = ((LR * CR - LF * CF) / IZ) * beta \
        - ((LF**2 * CF + LR**2 * CR) / (IZ * vx)) * r \
        + (LF * CF / IZ) * delta_f \
        - (LR * CR / IZ) * delta_r

    return [dbeta, dr, r, vx * (beta + psi)]  # small-angle lateral kinematics


def simulate(vx, k, name):
    t_eval = np.linspace(0, 6, 3001)
    sol = solve_ivp(dynamics, (0, 6), [0, 0, 0, 0], args=(vx, k),
                    t_eval=t_eval, max_step=0.01, rtol=1e-8, atol=1e-10)
    steer = np.array([steering_profile(t, k) for t in sol.t])
    return {"name": name, "t": sol.t, "beta": sol.y[0], "r": sol.y[1],
            "y": sol.y[3], "delta_f": steer[:, 0], "delta_r": steer[:, 1]}


def k_star(v):
    """Rear/front steer ratio giving zero steady-state sideslip at speed v (m/s)."""
    return -(LR - M * LF * v**2 / (CR * L)) / (LF + M * LR * v**2 / (CF * L))


def plot_cases(results, key, scale, ylabel, title, filename):
    fig, ax = plt.subplots()
    for res in results:
        ax.plot(res["t"], scale * res[key], linewidth=1.4, label=res["name"])
    ax.set(xlabel="Time (s)", ylabel=ylabel, title=title)
    ax.grid(True)
    ax.legend(loc="best")
    fig.savefig(OUT_DIR / filename, dpi=150, bbox_inches="tight")
    plt.close(fig)


def main():
    OUT_DIR.mkdir(exist_ok=True)
    deg = np.rad2deg(1)

    # Part 1: fixed-gain comparison at 50 km/h
    vx = 13.89
    cases = [(0.0, "2WS"), (-0.3, "4WS Opposite Phase"), (0.2, "4WS Same Phase")]
    results = [simulate(vx, k, name) for k, name in cases]

    plot_cases(results, "delta_f", deg, r"$\delta_f$ (deg)", "Front Steering Input", "front_steering.png")
    plot_cases(results, "delta_r", deg, r"$\delta_r$ (deg)", "Rear Steering Input", "rear_steering.png")
    plot_cases(results, "beta", deg, r"$\beta$ (deg)", "Sideslip Angle Response", "sideslip.png")
    plot_cases(results, "r", deg, "r (deg/s)", "Yaw Rate Response", "yaw_rate.png")
    plot_cases(results, "y", 1.0, "Lateral position y (m)", "Lane Change Lateral Motion", "lateral_position.png")

    print("50 km/h peak values:")
    for res in results:
        print(f"  {res['name']:<20}  |beta| = {np.max(np.abs(res['beta'])) * deg:.2f} deg"
              f"   |r| = {np.max(np.abs(res['r'])) * deg:.1f} deg/s   y_final = {res['y'][-1]:.2f} m")

    # Part 2: speed-scheduled gain
    v0 = np.sqrt(CR * LR * L / (M * LF))
    v = np.linspace(1, 40, 400)
    fig, ax = plt.subplots()
    ax.plot(v * 3.6, k_star(v), linewidth=1.6)
    ax.axhline(0, color="k", linestyle=":")
    ax.axvline(v0 * 3.6, linestyle="--", color="gray")
    ax.annotate(f"{v0 * 3.6:.0f} km/h", (v0 * 3.6, 0.05))
    ax.set(xlabel="Speed (km/h)", ylabel=r"$K^* = \delta_r / \delta_f$",
           title="Zero-Sideslip Rear Steering Gain vs Speed")
    ax.grid(True)
    fig.savefig(OUT_DIR / "k_schedule.png", dpi=150, bbox_inches="tight")
    plt.close(fig)
    print(f"\nK* at 50 km/h = {k_star(13.89):.3f}, sign change at {v0 * 3.6:.1f} km/h")

    vh = 27.78  # 100 km/h
    hw = [simulate(vh, 0.0, "2WS"),
          simulate(vh, -0.3, "Fixed K = -0.3"),
          simulate(vh, k_star(vh), f"Scheduled K* = {k_star(vh):.2f}")]
    plot_cases(hw, "beta", deg, r"$\beta$ (deg)", "Sideslip at 100 km/h", "sideslip_100kmh.png")
    plot_cases(hw, "r", deg, "r (deg/s)", "Yaw Rate at 100 km/h", "yaw_rate_100kmh.png")


if __name__ == "__main__":
    main()
